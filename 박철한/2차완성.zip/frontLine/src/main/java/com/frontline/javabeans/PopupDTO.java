package com.frontline.javabeans;

public class PopupDTO {
	private String popupImage;
	
	public PopupDTO() {
		
	}
	
	public PopupDTO(String popupImage) {
		this.popupImage = popupImage;
	}

	public String getPopupImage() {
		return popupImage;
	}

	public void setPopupImage(String popupImage) {
		this.popupImage = popupImage;
	}
}
